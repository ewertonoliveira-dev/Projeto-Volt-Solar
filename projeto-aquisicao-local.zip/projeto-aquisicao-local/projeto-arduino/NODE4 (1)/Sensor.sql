create database sensor;
use sensor;